﻿using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;
using Universidade.Infra;
using System.Reflection;
using System;

class Program
{
    static void Main()
    {
    Console.WriteLine("Hello, World!");
    }
}
