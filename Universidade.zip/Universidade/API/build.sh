#!/bin/bash

docker-compose -f docker-compose.ci.build.yml up --build